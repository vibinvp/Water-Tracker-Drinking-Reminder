 import 'package:plantshopee/model/cart_model.dart';

double totalSum(List<CartModel> cart) {
    double sum = 0;
    for (var item in cart) {
      sum += item.price * item.quantity;
    }
    return sum;
  }