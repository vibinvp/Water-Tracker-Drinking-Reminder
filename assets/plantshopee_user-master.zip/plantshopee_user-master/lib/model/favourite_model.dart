

class FavouritesModel {
  String productId;
  String userId;
  String favId;
  FavouritesModel({
    required this.productId,
    required this.userId,
    required this.favId,
  });

  Map<String, dynamic> toJson() {
    return {
      'productId': productId,
      'userId': userId,
      'favId': favId,
    };
  }

  static FavouritesModel fromJson(Map<String, dynamic> map) {
    return FavouritesModel(
      productId: map['productId'] ?? '',
      userId: map['userId'] ?? '',
      favId: map['favId'] ?? '',
    );
  }
}
