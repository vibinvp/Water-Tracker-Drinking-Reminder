import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:plantshopee/model/address_model.dart';
import 'package:plantshopee/model/cart_model.dart';
import 'package:plantshopee/model/favourite_model.dart';
import 'package:plantshopee/model/order_model.dart';
import 'package:plantshopee/model/plant_model.dart';
import 'package:plantshopee/utils/toast.dart';
import 'package:uuid/uuid.dart';

Stream<List<PlantModel>> readPlants() =>
    FirebaseFirestore.instance.collection('Products').snapshots().map((event) =>
        event.docs.map((doc) => PlantModel.fromJson(doc.data())).toList());

Stream<PlantModel> getCart(String id) => FirebaseFirestore.instance
    .collection('Products')
    .doc(id)
    .snapshots()
    .map((event) => PlantModel.fromJson(event.data()!));

Stream<List<CartModel>> getAllCartItems() => FirebaseFirestore.instance
    .collection('cartCollection')
    .doc(FirebaseAuth.instance.currentUser!.uid)
    .collection('cart')
    .snapshots()
    .map((event) =>
        event.docs.map((e) => CartModel.fromJson(e.data())).toList());

Future<String> addToCart(CartModel item) async {
  String res = 'Some error occured';
  try {
    DocumentReference<Map<String, dynamic>> cartUser = FirebaseFirestore
        .instance
        .collection('cartCollection')
        .doc(FirebaseAuth.instance.currentUser!.uid);
    await cartUser.collection('cart').doc(item.productId).set(item.toJson());
    res = 'success';
  } catch (err) {
    print('...........$err');
  }
  return res;
}

Future<String> addToFav(BuildContext context, String productId) async {
  String id = const Uuid().v1();
  FavouritesModel fav = FavouritesModel(
      productId: productId,
      userId: FirebaseAuth.instance.currentUser!.uid,
      favId: id);
  String res = 'Some error occured';

  try {
    FirebaseFirestore.instance
        .collection('favourites')
        .doc(productId)
        .set(fav.toJson())
        .then((value) {
      // toast(context, 'Added to Favourite', icon: Icons.check);
    });
    res = 'Added to favourites';
  } catch (err) {
    print(err);
  }
  return res;
}

Future<int> incrementQuantity(String id) async {
  int quantity = 1;
  final cart = FirebaseFirestore.instance
      .collection('cartCollection')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('cart')
      .doc(id);
  await cart.get().then((value) {
    quantity = value.data()!['quantity'];
    quantity++;
  });
  cart.update({'quantity': quantity});
  return quantity;
}

Future<int> decrementQuantity(String id) async {
  int quantity = 1;
  final cart = FirebaseFirestore.instance
      .collection('cartCollection')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('cart')
      .doc(id);
  await cart.get().then((value) {
    quantity = value.data()!['quantity'];
    if (quantity > 1) {
      quantity--;
    }
  });
  cart.update({'quantity': quantity});
  return quantity;
}

deleteCartItems(String id) async {
  FirebaseFirestore.instance
      .collection('cartCollection')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('cart')
      .doc(id)
      .delete();
}

Future<bool> addAddress(AddressModel address) async {
  bool isAddress = false;
  final addressCollection = FirebaseFirestore.instance
      .collection('address')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('userAddress');
  await addressCollection.add(address.toJson()).then((value) {
    address.id = value.id;
    value.set(address.toJson());
  });

  final isAddressExist = await addressCollection.get();
  if (isAddressExist.docs.isNotEmpty) {
    isAddress = true;
  }

  return isAddress;
}

updateAddress(AddressModel address) async {
  bool isAddress = false;
  final addressCollection = FirebaseFirestore.instance
      .collection('address')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('userAddress');
  await addressCollection.doc(address.id).set(address.toJson());
  final isAddressExist = await addressCollection.get();
  if (isAddressExist.docs.isNotEmpty) {
    isAddress = true;
  }

  return isAddress;
}

Future<bool> isAddress() async {
  bool isAddress = false;
  final addressCollection = await FirebaseFirestore.instance
      .collection('address')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .collection('userAddress')
      .get();
  if (addressCollection.docs.isNotEmpty) {
    isAddress = true;
  }
  return isAddress;
}

Future<bool> addOrders(OrderModel order) async {
  const uuid = Uuid();
  final id = uuid.v1();
  order.orderId = id;
  order.userId = FirebaseAuth.instance.currentUser!.uid;
  bool isAdded = false;
  final orderCollection =
      FirebaseFirestore.instance.collection('orders').doc(id);
  await orderCollection.set(order.toJson()).then((value) {
    isAdded = true;
  });

  return isAdded;
}

Future<PlantModel> getProduct(String id) async {
  PlantModel product = await FirebaseFirestore.instance
      .collection('Products')
      .doc(id)
      .get()
      .then((value) => PlantModel.fromJson(value.data()!));
  return product;
}

clearCart(String id) {
  FirebaseFirestore.instance
      .collection('cartCollection')
      .doc(id)
      .collection('cart')
      .get()
      .then((value) {
    for (var item in value.docs) {
      item.reference.delete();
    }
  });
}

decreaseQuantity(String id, int quantity) async {
  FirebaseFirestore.instance.collection('Products').doc(id).get().then((value) {
    final quantityFrom = value.data()!['quantity'];
    FirebaseFirestore.instance
        .collection('Products')
        .doc(id)
        .update({'quantity': quantityFrom - quantity});
  });
}

getUserName() => FirebaseFirestore.instance
    .collection('users')
    .doc(FirebaseAuth.instance.currentUser!.uid)
    .get()
    .then((value) => value.data()!['username']);

// Future<bool> isFav(String id) async {
//   bool isFav = false;
//   final fav = await FirebaseFirestore.instance.collection('favourites').get();
//   String favId = fav.docs.map((e) => e.data()['productId']) as String;
//   if (favId == id) {
//     isFav = true;
//   }
//   return isFav;
// }

Stream<List<FavouritesModel>> isFav() => FirebaseFirestore.instance
    .collection('favourites')
    .snapshots()
    .map((event) =>
        event.docs.map((doc) => FavouritesModel.fromJson(doc.data())).toList());
