import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:plantshopee/model/chat_model.dart';
import 'package:plantshopee/model/order_model.dart';

class ChatApi {
  static Future sendMessage(OrderModel order, String message) async {
    final chatCollection = FirebaseFirestore.instance
        .collection('chats')
        .doc(order.userId)
        .collection('messages')
        .doc(order.orderId)
        .collection('chat');
   
    final newMessage = ChatModel(
        userId: order.userId!,
        message: message,
        itsMe: true,
        createdAt: DateTime.now(),
        orderId: order.orderId!);

    chatCollection.add(newMessage.toJson()).then((value) => {
          FirebaseFirestore.instance
              .collection('chats')
              .doc(order.userId)
              .set({'userId': order.userId}).then((value) {
            FirebaseFirestore.instance
                .collection('chats')
                .doc(order.userId)
                .collection('messages')
                .doc(order.orderId)
                .set({'orderId': order.orderId});
          })
        });
  }


  static Stream<List<ChatModel>> getChart(OrderModel order) =>
      FirebaseFirestore.instance
          .collection('chats')
          .doc(order.userId)
          .collection('messages')
          .doc(order.orderId)
          .collection('chat')
          .orderBy('createdAt', descending: false)
          .snapshots()
          .map((event) =>
              event.docs.map((doc) => ChatModel.fromJson(doc.data())).toList());
}
