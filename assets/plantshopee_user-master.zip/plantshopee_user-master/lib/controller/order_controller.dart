import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:plantshopee/controller/notifications.dart';
import 'package:plantshopee/model/order_model.dart';

class OrderController extends GetxController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final NotificationController _notification = Get.find();
  List<OrderModel> order = [];

  getOrders() async {
    order.clear();
    final orderCollection = await _db.collection('orders').get();
    List<OrderModel> listOrder =
        orderCollection.docs.map((e) => OrderModel.fromJson(e.data())).toList();
    for (var item in listOrder) {
      if ((item.userId) == (_auth.currentUser!.uid)) {
        order.add(item);
      }
    }
    update();
  }

  bool changeStatus(OrderModel model, String currentStatus) {
    bool canceled = false;
    final orderCollection =
        FirebaseFirestore.instance.collection('orders').doc(model.orderId);
    model.status = currentStatus;
    orderCollection.set(model.toJson()).then((value) {
      canceled = true;
      _notification.sendPushMessage(
          _notification.mtoken!, 'Product was $currentStatus', model.userId!);
    });
    getOrders();
    update();
    return canceled;
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getOrders();
  }
}
