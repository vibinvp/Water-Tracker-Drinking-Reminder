import 'package:get/get.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/plant_model.dart';

class SearchController extends GetxController {
  final allPlants = <PlantModel>[].obs;
  final searchPlant = <PlantModel>[].obs;

  final searchPlants = <PlantModel>[].obs;
  search(String value) {
    if (value == '') {
      searchPlant.value = allPlants;
    } else {
      searchPlant.value = allPlants
          .where((plant) =>
              plant.title.toLowerCase().contains(value.toLowerCase()))
          .toList();
    }
  }

  @override
  void onInit() {
    super.onInit();
    allPlants.bindStream(readPlants());
    searchPlant.value = allPlants;
  }
}
