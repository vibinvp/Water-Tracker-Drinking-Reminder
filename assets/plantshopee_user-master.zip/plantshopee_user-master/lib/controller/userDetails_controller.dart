import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:get/get.dart';
import 'package:plantshopee/model/user_model.dart';

class UserDetailsController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  UserModel? userModel;

  void getUserDetails() async {
    _firestore
        .collection('users')
        .doc(_auth.currentUser!.uid)
        .get()
        .then((value) {
      userModel = UserModel.formJson(value.data()!);
    });
    update();
  }

  profileImageUpload(FilePickerResult image) async {
    final FirebaseStorage storage = FirebaseStorage.instance;
    final path = image.files.single.path;
    final fileName = image.files.single.name;
    File file = File(path!);
    try {
      final ref = storage.ref('profileImages/$fileName');
      final link = await ref.putFile(file).whenComplete(() => null);
      userModel!.image = await link.ref.getDownloadURL();
      _firestore
          .collection('users')
          .doc(_auth.currentUser!.uid)
          .set(userModel!.toJson());
      getUserDetails();
    } on FirebaseException catch (e) {
      print(e);
    }
    update();
  }

  updateProfileImage(FilePickerResult image) async {
    final FirebaseStorage storage = FirebaseStorage.instance;
    storage.refFromURL(userModel!.image!).delete();
    profileImageUpload(image);
    update();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getUserDetails();
  }
}
