import 'package:get/get.dart';

class RadioController extends GetxController {
      String payment = 'RazorPay';
      void onClickRadioButton(value) {
      payment = value;
      update();
      }
}
