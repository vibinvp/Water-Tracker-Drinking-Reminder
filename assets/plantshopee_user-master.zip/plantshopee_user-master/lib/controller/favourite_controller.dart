import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/favourite_model.dart';
import 'package:plantshopee/model/plant_model.dart';

class FavouriteController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  List<PlantModel> favourite = [];
  List<FavouritesModel> fav = [];
  bool isLoading = true;

  getFavProduct() async {
    isLoading = true;
    favourite.clear();
    fav.clear();
    final favCollection = await _firestore.collection('favourites').get();
    List<FavouritesModel> allFav = favCollection.docs
        .map((e) => FavouritesModel.fromJson(e.data()))
        .toList();
    for (var item in allFav) {
      if (item.userId == _auth.currentUser!.uid) {
        fav.add(item);
        favourite.add(await getProduct(item.productId));
      }
    }
    isLoading = false;
    update();
  }

  deleteFav(String id) async {
    isLoading = true;
    update();
    _firestore.collection('favourites').doc(id).delete();
    await getFavProduct();
  }

  @override
  void onInit() {
    super.onInit();
    getFavProduct();
  }
}
