import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:plantshopee/model/address_model.dart';

class AddressController extends GetxController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  RxList<AddressModel> allAddress = <AddressModel>[].obs;
  AddressModel? address;

  getAddress() async {
    allAddress.clear();
    final addressCollection = await _db
        .collection('address')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .collection('userAddress')
        .get();
    List<AddressModel> address = addressCollection.docs
        .map((e) => AddressModel.fromJson(e.data()))
        .toList();
    allAddress.addAll(address);
    update();
  }

  deleteAddress(String id) async {
    await _db
        .collection('address')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .collection('userAddress')
        .doc(id)
        .delete();
    await getAddress();
    update();
  }

  void addressSelector(AddressModel value) {
    address = value;
    update();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getAddress();
  }


}
