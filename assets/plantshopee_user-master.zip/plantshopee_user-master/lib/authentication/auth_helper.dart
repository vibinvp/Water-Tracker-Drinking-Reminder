import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:plantshopee/model/user_model.dart';

class AuthMethods {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _DB = FirebaseFirestore.instance;

  Future<String> signUpUser(
      {required String email,
      required String password,
      required String username,
      required String mobileNumber}) async {
    String? token = await FirebaseMessaging.instance.getToken();
    String res = 'Some error occured';
    try {
      if (email.isNotEmpty || password.isNotEmpty || username.isNotEmpty) {
        final newUser = await _auth.createUserWithEmailAndPassword(
            email: email, password: password);

        final user = UserModel(
            username: username,
            userId: newUser.user!.uid,
            email: email,
            mobileNumber: mobileNumber,
            role: 'user',
            token: token!);
        await _DB.collection('users').doc(newUser.user!.uid).set(user.toJson());
        res = "success";
      }
    } on FirebaseAuthException catch (err) {
      if (err.code == 'email-already-in-use') {
        res = 'The email address is already in use by another account';
      }
    }
    print(res);
    return res;
  }

  Future<String> loginUser(
      {required String email, required String password}) async {
    String? token = await FirebaseMessaging.instance.getToken();
    String res = 'some error occured';
    try {
      if (email.isNotEmpty || password.isNotEmpty) {
        await _auth
            .signInWithEmailAndPassword(email: email, password: password)
            .then((value) {
          FirebaseFirestore.instance
              .collection('users')
              .doc(FirebaseAuth.instance.currentUser!.uid)
              .update({'token': token});
        });
        res = 'Loged In Successfuly';
      }
    } on FirebaseAuthException catch (err) {
      if (err.code == 'invalid-email') {
        res = 'Invalid email or password';
      }
      if (err.code == 'user-not-found') {
        res = 'User not found';
      }
      if (err.code == 'invalid-email') {
        res = 'Invalid emial address';
      }
    }
    return res;
  }

  logoutUser() async {
    await _auth.signOut();
  }
}
