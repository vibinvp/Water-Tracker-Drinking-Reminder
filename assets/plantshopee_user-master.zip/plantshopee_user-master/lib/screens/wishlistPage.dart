import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/controller/favourite_controller.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/screens/cartPage.dart';
import 'package:plantshopee/screens/productInfo.dart';
import '../constanse/constanse.dart';

class FavouritesScreen extends StatelessWidget {
  FavouritesScreen({Key? key}) : super(key: key);
  final FavouriteController _controller = Get.find();

  @override
  Widget build(BuildContext context) {
    _controller.getFavProduct();
    // Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          "My Favourites",
          style: subHeading,
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (ctx) => CartPage()));
            },
            icon: const Icon(
              Icons.shopping_bag,
              size: 22,
            ),
          ),
          // const SizedBox(
          //   width: 8,
          // ),
          // CircleAvatar(
          //   backgroundColor: Colors.black,
          //   radius: 10,
          //   child: Text(
          //     _controller.fav.length.toString(),
          //     style: const TextStyle(color: Colors.white),
          //   ),
          // ),
          const SizedBox(
            width: 10,
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 10),
        child: GetBuilder<FavouriteController>(
          builder: (controller) {
            if (controller.isLoading == false) {
              if (controller.favourite.isEmpty) {
                return const Center(
                  child: Text('You have no favourites'),
                );
              } else {
                return ListView.builder(
                    itemBuilder: ((context, index) {
                      final plant = controller.favourite[index];
                      final fav = controller.fav[index];

                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Card(
                          color: Colors.grey.shade100,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical:8.0),
                            child: ListTile(
                              horizontalTitleGap: 20,
                              onTap: () {
                                Navigator.of(context).push(MaterialPageRoute(
                                    builder: (ctx) => ProductInfo(
                                          model: plant,
                                        )));
                              },
                              leading: Image.network(plant.image!),
                              title: Text(plant.title),
                              subtitle: Text("₹ ${plant.price}",style: const TextStyle(color: Colors.green,fontWeight: FontWeight.w700,fontSize: 16),),
                              trailing: IconButton(
                                onPressed: () {
                                  controller.deleteFav(fav.productId);
                                },
                                icon: const Icon(
                                  Icons.close,
                                  color: delete,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                    // separatorBuilder: (ctx, index) => const Divider(),
                    itemCount: controller.favourite.length);
              }
            } else {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
          },
        ),
      ),
    );
  }
}
