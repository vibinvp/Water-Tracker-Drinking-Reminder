import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/notifications.dart';
import 'package:plantshopee/customWidgets/chat_container.dart';
import 'package:plantshopee/firebase/chat_api.dart';
import 'package:plantshopee/model/chat_model.dart';
import 'package:plantshopee/model/order_model.dart';

class HelpScreen extends StatelessWidget {
  OrderModel order;
  HelpScreen({Key? key, required this.order}) : super(key: key);

  final _messageController = TextEditingController();
  final NotificationController _notification = Get.find();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'Plantshopee Support',
          style: subHeading,
        ),
      ),
      body: Stack(
        children: [
          Container(
            height: size.height * 0.1,
            width: double.infinity,
            color: Colors.green,
          ),
          Container(
            height: double.infinity,
            width: double.infinity,
            decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20))),
            child: Column(
              children: [
                Expanded(
                  child: StreamBuilder<List<ChatModel>>(
                      stream: ChatApi.getChart(order),
                      builder: ((context, snapshot) {
                        if (snapshot.data == null) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        } else {
                          if (snapshot.data!.isEmpty) {
                            return const Center(
                              child: Text("Hay, how may help you"),
                            );
                          } else {
                            return ListView.builder(
                                itemCount: snapshot.data!.length,
                                itemBuilder: ((context, index) {
                                  final chat = snapshot.data![index];
                                  if (chat.orderId == order.orderId) {
                                    return ChatContainer(
                                        message: chat.message,
                                        isMe: chat.itsMe);
                                  } else {
                                    return const SizedBox();
                                  }
                                }));
                          }
                        }
                      })),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _messageController,
                            textCapitalization: TextCapitalization.sentences,
                            autocorrect: true,
                            enableSuggestions: true,
                            decoration: InputDecoration(
                                filled: true,
                                fillColor: Colors.grey.shade100,
                                hintText: 'Type your message',
                                border: OutlineInputBorder(
                                    borderSide: const BorderSide(width: 0),
                                    gapPadding: 10,
                                    borderRadius: BorderRadius.circular(25))),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        InkWell(
                            onTap: () {
                              sendMessage(context);
                            },
                            child: const CircleAvatar(
                              radius: 26,
                              child: Icon(Icons.send),
                            ))
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void sendMessage(BuildContext context) async {
    String message = _messageController.text.trim();
    FocusScope.of(context).unfocus();
    ChatApi.sendMessage(order, message);
    _notification.sendPushMessage(_notification.mtoken!, message, 'New Chat');
    _messageController.clear();
  }
}
