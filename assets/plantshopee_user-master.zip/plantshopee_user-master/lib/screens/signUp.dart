import 'package:flutter/material.dart';
import 'package:plantshopee/authentication/auth_helper.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/screens/loginPage.dart';
import 'package:plantshopee/customWidgets/popUp/snackbar.dart';
import 'package:plantshopee/utils/validationPattern.dart';

class SignUp extends StatelessWidget {
  SignUp({Key? key}) : super(key: key);
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _mobileController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPassController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          "Create Account",
          style: subHeading,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 28, right: 28, top: 10),
        child: ListView(
          children: [
            Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextFormField(
                    controller: _nameController,
                    decoration: InputDecoration(
                        hintText: 'Full Name',
                        filled: true,
                        fillColor: Colors.grey.shade300,
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10)))),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your name';
                      }
                      return null;
                    },
                  ),
                  kHeight18,
                  TextFormField(
                    controller: _emailController,
                    decoration: InputDecoration(
                        hintText: 'Email Address',
                        filled: true,
                        fillColor: Colors.grey.shade300,
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10)))),
                    validator: (value) => validateEmail(value),
                  ),
                  kHeight18,
                  TextFormField(
                    keyboardType: TextInputType.phone,
                    controller: _mobileController,
                    decoration: InputDecoration(
                        hintText: 'Mobile Number',
                        filled: true,
                        fillColor: Colors.grey.shade300,
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10)))),
                    validator: (value) => validateMobile(value!),
                  ),
                  kHeight18,
                  TextFormField(
                      controller: _passwordController,
                      decoration: InputDecoration(
                          hintText: 'Password',
                          filled: true,
                          fillColor: Colors.grey.shade300,
                          border: const OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)))),
                      validator: (value) => validatePassword(value)),
                  kHeight18,
                  TextFormField(
                    controller: _confirmPassController,
                    decoration: InputDecoration(
                        hintText: 'Confirm Password',
                        filled: true,
                        fillColor: Colors.grey.shade300,
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10)))),
                    validator: (value) {
                      if ((_passwordController.text.trim() !=
                              _confirmPassController.text.trim()) ||
                          _confirmPassController.text.trim().isEmpty) {
                        return 'Password not mach';
                      } else {
                        return null;
                      }
                    },
                  ),
                ],
              ),
            ),
            kHeight18,
            const Text(
              "By Signing up you agree to our Terms Condition & Privacy Policy.",
              style: TextStyle(color: Colors.grey),
            ),
            kHeight18,
            SizedBox(
              width: size.width,
              height: 45,
              child: ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    final res = await AuthMethods().signUpUser(
                        email: _emailController.text.trim(),
                        password: _passwordController.text.trim(),
                        username: _nameController.text.trim(),
                        mobileNumber: _mobileController.text.trim());
                    if (res == 'success') {
                      Navigator.pop(context);
                    showSnackbar(context, 'Account created successfully');
                    } else {
                      showSnackbar(context, 'Please check your Internet connection');
                    }
                  }
                },
                child: const Text(
                  "Sign Up",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(themeColor)),
              ),
            ),
            kHeight15,
            // SizedBox(
            //   width: size.width,
            //   height: 45,
            //   child: ElevatedButton(
            //     onPressed: () {},
            //     child: Row(
            //       mainAxisAlignment: MainAxisAlignment.center,
            //       children: const [
            //         Icon(Icons.login),
            //         SizedBox(
            //           width: 10,
            //         ),
            //         Text(
            //           "Login with Google",
            //           style:
            //               TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            //         ),
            //       ],
            //     ),
            //     style: ButtonStyle(
            //         backgroundColor: MaterialStateProperty.all(
            //             const Color.fromARGB(255, 100, 134, 200))),
            //   ),
            // ),
            // kHeight15,
            Wrap(
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                const Text('Enter the Details to SignUp.'),
                TextButton(
                    onPressed: () {
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (ctx) => LoginPage()),
                          (route) => false);
                    },
                    child: const Text(
                      'Already have account?',
                      style: TextStyle(color: themeColor),
                    ))
              ],
            ),
          ],
        ),
      ),
    );
  }

  validateMobile(String value) {
    if (value.length != 10) {
      return 'Mobile Number must be of 10 digit';
    } else {
      return null;
    }
  }
}
