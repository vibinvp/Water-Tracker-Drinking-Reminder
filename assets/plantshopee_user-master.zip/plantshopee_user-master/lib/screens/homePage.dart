import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/address_controller.dart';
import 'package:plantshopee/controller/favourite_controller.dart';
import 'package:plantshopee/controller/notifications.dart';
import 'package:plantshopee/controller/order_controller.dart';
import 'package:plantshopee/controller/search_controller.dart';
import 'package:plantshopee/controller/userDetails_controller.dart';
import 'package:plantshopee/drawer/drawer.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/favourite_model.dart';
import 'package:plantshopee/model/plant_model.dart';
import 'package:plantshopee/screens/cartPage.dart';
import 'package:plantshopee/screens/productInfo.dart';
import 'package:plantshopee/customWidgets/plant.dart';
import 'package:plantshopee/screens/wishlistPage.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    final _search = Get.put(SearchController());
    Get.put(UserDetailsController()).getUserDetails();
    Get.put(NotificationController());
    Get.put(AddressController());
    Get.put(OrderController());
    Get.put(FavouriteController());
    return Scaffold(
      backgroundColor: Colors.white,
      drawer: const CustomDrawer(),
      appBar: AppBar(
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'Plants',
          style: subHeading,
        ),
        actions: [
          IconButton(
            padding: const EdgeInsets.only(right: 10),
            onPressed: () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (ctx) => FavouritesScreen()));
            },
            icon: const Icon(
              Icons.favorite,
              size: 22,
            ),
          ),
          InkWell(
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (ctx) => CartPage()));
            },
            child: const Icon(Icons.shopping_bag),
          ),
          const SizedBox(
            width: 20,
          ),
        ],
        backgroundColor: Colors.white,
        foregroundColor: themeColor,
      ),
      body: SafeArea(
          child: Padding(
        padding: EdgeInsets.symmetric(horizontal: size.width * 0.03),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: TextFormField(
                onChanged: (value) {
                  _search.search(value);
                },
                decoration: InputDecoration(
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 16.0, horizontal: 18.0),
                    hintText: 'Search',
                    filled: true,
                    fillColor: Colors.grey.shade300,
                    border: const OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.all(Radius.circular(10)))),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Expanded(child: GetX<SearchController>(builder: (snap) {
              if (snap.searchPlant.isEmpty) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              } else {
                List<PlantModel>? plant = snap.searchPlant;
                if (plant.isEmpty) {
                  return Center(
                    child: Text(
                      'No Products Fount',
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.grey.shade700,
                          fontWeight: FontWeight.bold),
                    ),
                  );
                } else {
                  return GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                            childAspectRatio: 0.8,
                            crossAxisCount: 2,
                            crossAxisSpacing: 10,
                            mainAxisSpacing: 5),
                    itemBuilder: (ctx, index) => InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (ctx) => ProductInfo(
                                        model: plant[index],
                                      )));
                        },
                        child: StreamBuilder<List<FavouritesModel>>(
                            stream: isFav(),
                            builder: (context, snapshot) {
                              List<FavouritesModel> fav = [];
                              if (snapshot.data == null) {
                                return const Center(
                                  child: CircularProgressIndicator(),
                                );
                              } else {
                                for (var item in snapshot.data!) {
                                  if ((item.productId == plant[index].id &&
                                      (item.userId ==
                                          FirebaseAuth
                                              .instance.currentUser!.uid))) {
                                    fav.add(item);
                                  }
                                }
                              }
                              return Plant(model: plant[index], fav: fav);
                            })),
                    itemCount: plant.length,
                  );
                }
              }
            }))
          ],
        ),
      )),
    );
  }
}
