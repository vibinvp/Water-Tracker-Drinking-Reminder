import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/address_controller.dart';
import 'package:plantshopee/controller/userDetails_controller.dart';
import 'package:plantshopee/customWidgets/shippingAddress.dart';
import 'package:plantshopee/screens/addAddress.dart';
import 'package:plantshopee/screens/cartPage.dart';

class ProfilePage extends StatelessWidget {
  ProfilePage({Key? key}) : super(key: key);
  // final UserDetailsController _controller = Get.find();

  @override
  Widget build(BuildContext context) {
    // _controller.getUserDetails();
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          elevation: 0,
          centerTitle: true,
          title: const Text(
            'Profile',
            style: subHeading,
          ),
          actions: [
            IconButton(
                onPressed: () {
                  Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (ctx) => CartPage()));
                },
                icon: const Icon(Icons.shopping_bag))
          ],
          backgroundColor: const Color.fromARGB(255, 49, 163, 68),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: ListView(
            children: [
              GetBuilder<UserDetailsController>(builder: (controller) {
                final user = controller.userModel;
                if (user == null) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                } else {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(30),
                              bottomLeft: Radius.circular(30)),
                          color: Color.fromARGB(255, 49, 163, 68),
                        ),
                        height: 200,
                        width: size.width,
                        child: Stack(
                          children: [
                            Align(
                              alignment: Alignment.topCenter,
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 30),
                                child: ClipRRect(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(50)),
                                    child: (user.image != null)
                                        ? Image.network(user.image!)
                                        : Image.asset(
                                            'assets/images/profile.png',
                                          )),
                              ),
                            ),
                            Positioned(
                              right: 70,
                              bottom: 30,
                              child: InkWell(
                                onTap: () async {
                                  FilePickerResult? image =
                                      await FilePicker.platform.pickFiles(
                                          allowMultiple: false,
                                          type: FileType.image);
                                  if (image == null) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                            content: Text('No file selected')));
                                  } else {
                                    if (user.image == null) {
                                      controller.profileImageUpload(image);
                                    } else {
                                      controller.updateProfileImage(image);
                                    }
                                  }
                                },
                                child: const CircleAvatar(
                                  child: Icon(Icons.camera_enhance),
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 5),
                                child: Text(
                                  user.username,
                                  style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                      kHeight18,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Personal Info',
                            style: subHeading,
                          ),
                          kHeight18,
                          Text('Id : ${user.userId!}'),
                          const SizedBox(
                            height: 10,
                          ),
                          Text('email : ${user.email}'),
                          const SizedBox(
                            height: 10,
                          ),
                          Text('mobile : ${user.mobileNumber}'),
                        ],
                      )
                    ],
                  );
                }
              }),
              kHeight18,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Address you are added',
                    style: subHeading,
                  ),
                  IconButton(
                    onPressed: () {
                      Navigator.of(context).push(
                          MaterialPageRoute(builder: (ctx) => AddAddress()));
                    },
                    icon: const Icon(
                      Icons.add,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
              kHeight15,
              GetBuilder<AddressController>(
                builder: (item) {
                  if (item.allAddress.isNotEmpty) {
                    return ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: item.allAddress.length,
                      itemBuilder: (ctx, index) {
                        final address = item.allAddress[index];
                        return InkWell(
                          onTap: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (ctx) => AddAddress(
                                      address: address,
                                    )));
                          },
                          child: ShippingAddress(
                            address: address,
                          ),
                        );
                      },
                    );
                  } else {
                    return const Center(
                      child: Text('Please add an Address'),
                    );
                  }
                },
              ),
            ],
          ),
        ));
  }
}
