import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:plantshopee/authentication/auth_helper.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/customWidgets/popUp/snackbar.dart';
import 'package:plantshopee/screens/signUp.dart';

class LoginPage extends StatelessWidget {
  LoginPage({Key? key}) : super(key: key);
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              child: Padding(
                padding: EdgeInsets.only(
                    top: size.height * 0.1, left: size.width * 0.07),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      "Hello",
                      style:
                          TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      "There.",
                      style: TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF00FF47)),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: size.height * 0.04,
            ),
            SizedBox(
              width: size.width,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: size.width * 0.1),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text(
                      "Login",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    kHeight18,
                    Form(
                        key: _formkey,
                        child: Column(
                          children: [
                            TextFormField(
                              controller: _emailController,
                              keyboardType: TextInputType.emailAddress,
                              decoration: InputDecoration(
                                  prefixIcon: const Icon(Icons.email),
                                  hintText: 'Enter the Email',
                                  filled: true,
                                  fillColor: Colors.grey.shade300,
                                  border: const OutlineInputBorder(
                                      borderSide: BorderSide.none,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10)))),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter email Id';
                                }
                                return null;
                              },
                            ),
                            kHeight18,
                            TextFormField(
                              controller: _passwordController,
                              obscureText: true,
                              decoration: InputDecoration(
                                  prefixIcon: const Icon(Icons.key),
                                  hintText: 'Enter the Password',
                                  filled: true,
                                  fillColor: Colors.grey.shade300,
                                  border: const OutlineInputBorder(
                                      borderSide: BorderSide.none,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10)))),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter password';
                                }
                                return null;
                              },
                            ),
                          ],
                        )),
                    const SizedBox(
                      height: 30,
                    ),
                    SizedBox(
                      width: size.width,
                      height: 45,
                      child: ElevatedButton(
                        onPressed: () async {
                         if (_formkey.currentState!.validate()){
                            String res = await AuthMethods().loginUser(
                              email: _emailController.text.trim(),
                              password: _passwordController.text.trim());
                          showSnackbar(context, res);
                         } else {
                         }
                        },
                        child: const Text(
                          "Login",
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(themeColor)),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    // SizedBox(
                    //   width: size.width,
                    //   height: 45,
                    //   child: ElevatedButton(
                    //     onPressed: () {},
                    //     child: Row(
                    //       mainAxisAlignment: MainAxisAlignment.center,
                    //       children: const [
                    //         Icon(Icons.login),
                    //         SizedBox(
                    //           width: 10,
                    //         ),
                    //         Text(
                    //           "Login with Google",
                    //           style: TextStyle(
                    //               fontWeight: FontWeight.bold, fontSize: 18),
                    //         ),
                    //       ],
                    //     ),
                    //     style: ButtonStyle(
                    //         backgroundColor: MaterialStateProperty.all(
                    //             const Color.fromARGB(255, 100, 134, 200))),
                    //   ),
                    // ),
                    // kHeight18,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        const Text("New to MyShopee ? "),
                        TextButton(
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (ctx) => SignUp()));
                            },
                            child: const Text(
                              "Register",
                              style: TextStyle(
                                  color: themeColor,
                                  fontWeight: FontWeight.bold),
                            ))
                      ],
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      )),
    );
  }
}
