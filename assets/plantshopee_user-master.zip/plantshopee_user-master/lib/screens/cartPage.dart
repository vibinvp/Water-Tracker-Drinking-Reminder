import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/controller/address_controller.dart';
import 'package:plantshopee/customWidgets/cart_tile.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/address_model.dart';
import 'package:plantshopee/model/cart_model.dart';
import 'package:plantshopee/screens/addAddress.dart';
import 'package:plantshopee/screens/checkoutPage.dart';
import 'package:plantshopee/screens/homePage.dart';
import 'package:plantshopee/screens/wishlistPage.dart';
import 'package:plantshopee/utils/cart_totalsum.dart';
import '../constanse/constanse.dart';

class CartPage extends StatelessWidget {
  CartPage({Key? key}) : super(key: key);
  final AddressController controller = Get.find();
  double sum = 0.0;
  List<CartModel> cartModel = [];
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          "My Bag",
          style: subHeading,
        ),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                  builder: (ctx) =>  FavouritesScreen()));
            },
            icon: const Icon(
              Icons.favorite,
              size: 22,
            ),
          ),
         
          const SizedBox(
            width: 10,
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
              child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: StreamBuilder<List<CartModel>>(
                    stream: getAllCartItems(),
                    builder: (context, item) {
                      if (item.data == null) {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      } else {
                        if (item.data!.isEmpty) {
                          return const Center(
                            child: Text("No Cart Items Found"),
                          );
                        } else {
                          return ListView.builder(
                              itemBuilder: ((context, index) {
                                final cart =
                                    getCart(item.data![index].productId);
                                final quantity = item.data![index].quantity;
                                return createCartListItem(cart, quantity);
                              }),
                              itemCount: item.data!.length);
                        }
                      }
                    },
                  ))),
          kHeight18,
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Total",
                  style: subHeading,
                ),
                StreamBuilder<List<CartModel>>(
                    stream: getAllCartItems(),
                    builder: (context, item) {
                      if (item.data == null) {
                        return const SizedBox();
                      } else {
                        sum = totalSum(item.data!);
                        cartModel = item.data!;
                        return Text(
                          "₹ $sum",
                          style: subHeading,
                        );
                      }
                    })
              ],
            ),
          ),
          kHeight18,
          InkWell(
            onTap: () async {
              if (cartModel.isEmpty) {
                Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (ctx) => HomePage()),
                    (route) => false);
              } else {
                bool address = await isAddress();
                if (address) {
                  List<AddressModel> address = controller.allAddress;
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (ctx) => CheckoutPage()));
                } else {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (ctx) => AddAddress()));
                }
              }
            },
            child: Container(
              width: size.width,
              height: 50,
              color: themeColor,
              child: const Center(
                child: Text(
                  "CHECKOUT",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
