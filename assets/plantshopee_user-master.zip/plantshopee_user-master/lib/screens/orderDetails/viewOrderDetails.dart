import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/order_controller.dart';
import 'package:plantshopee/customWidgets/shippingAddress.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/order_model.dart';
import 'package:plantshopee/model/plant_model.dart';
import 'package:plantshopee/screens/help_screen.dart';
import 'package:plantshopee/screens/home.dart';

class ViewOrderDetails extends StatelessWidget {
  OrderModel order;

  ViewOrderDetails({
    Key? key,
    required this.order,
  }) : super(key: key);

  final OrderController _orderController = Get.find();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
          centerTitle: true,
          title: const Text(
            'Order Details',
            style: subHeading,
          )),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 20, left: 15, right: 15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text('Order ID : ${order.orderId}'),
              kHeight18,
              const Divider(),
              StreamBuilder<PlantModel>(
                  stream: getCart(order.cartModel.productId),
                  builder: (context, snapshot) {
                    final item = snapshot.data;
                    if (item == null) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    } else {
                      return ListTile(
                        isThreeLine: true,
                        contentPadding: const EdgeInsets.only(left: 10),
                        leading: Image.network(item.image!),
                        title: Text(item.title),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              order.status,
                              style: const TextStyle(color: Colors.blue),
                            ),
                            Text(
                                'Quantity : ${order.cartModel.quantity.toString()}')
                          ],
                        ),
                        trailing: Text(
                          '${order.totalPrice}',
                          style: const TextStyle(
                              color: Colors.green,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        ),
                      );
                    }
                  }),
              kHeight18,
              // const AmountContainer(),
              // kHeight18,
              const Align(
                alignment: Alignment.topLeft,
                child: Text(
                  'Shipped Address',
                ),
              ),
              kHeight18,
              ShippingAddress(
                address: order.address,
                status: false,
              ),
              kHeight18,
              SizedBox(
                width: size.width,
                height: 45,
                child: ElevatedButton(
                  onPressed: () {
                    if (order.status != 'cancel' && order.status != 'delivered') {
                      cancelOrderDialog(context);
                    } else {
                      Navigator.of(context).pushReplacement(
                          MaterialPageRoute(builder: (ctx) => const Home()));
                    }
                  },
                  child:
                      (order.status == 'cancel' || order.status == 'delivered')
                          ? const Text(
                              "Order Again",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 18),
                            )
                          : const Text(
                              "Cancel Order",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 18),
                            ),
                  style:
                      (order.status != 'cancel' && order.status != 'delivered')
                          ? ButtonStyle(
                              backgroundColor: MaterialStateProperty.all(
                              const Color.fromARGB(255, 255, 102, 92),
                            ))
                          : ButtonStyle(
                              backgroundColor: MaterialStateProperty.all(
                              const Color.fromARGB(255, 32, 120, 193),
                            )),
                ),
              ),
              kHeight18,
              SizedBox(
                width: size.width,
                height: 45,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (ctx) => HelpScreen(
                              order: order,
                            )));
                  },
                  child: const Text(
                    "Need Help ?",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(themeColor)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<String?> cancelOrderDialog(BuildContext context) {
    return showDialog<String>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('Are you sure want to cancel this order'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              if (order.status != 'cancel') {
                _orderController.changeStatus(order, 'cancel');
                Navigator.pop(ctx);
                Navigator.pop(context);
              }
            },
            child: const Text(
              'OK',
            ),
          ),
        ],
      ),
    );
  }
}
