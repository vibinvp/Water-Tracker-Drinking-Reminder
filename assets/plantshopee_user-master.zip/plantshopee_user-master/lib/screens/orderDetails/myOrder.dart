import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/order_controller.dart';
import 'package:plantshopee/model/order_model.dart';
import 'package:plantshopee/screens/orderDetails/viewOrderDetails.dart';

class MyOrder extends StatelessWidget {
  MyOrder({Key? key}) : super(key: key);
  final OrderController _orderController = Get.find();

  @override
  Widget build(BuildContext context) {
    _orderController.getOrders();
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
          centerTitle: true,
          title: const Text(
            'My Orders',
            style: subHeading,
          ),
        ),
        body: GetBuilder<OrderController>(
          builder: (controller) {
            if (controller.order.isEmpty) {
              return const Center(
                child: Text('No Order Found'),
              );
            } else {
              return ListView.builder(
                  itemBuilder: (context, index) {
                    final order = controller.order[index];
                    return OrderInfo(order: order);
                  },
                  itemCount: controller.order.length);
            }
          },
        ),
      ),
    );
  }
}

class OrderInfo extends StatelessWidget {
  OrderModel order;
  OrderInfo({
    Key? key,
    required this.order,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Card(
        color: bgCard,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Text(
                  'Order No : ${order.orderId}',overflow: TextOverflow.ellipsis,
                ),
              ),
             const SizedBox(
                height: 10,
              ),
               Text(
                'Ordered Date : ${order.createdDate}',
                style: const TextStyle(
                    color: Colors.grey, overflow: TextOverflow.ellipsis),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 5),
                child: Divider(),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Quantity : ${order.cartModel.quantity}'),
                  Text(
                      'Total Amount : ₹${(order.cartModel.quantity) * (order.cartModel.price)}')
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: 100,
                    height: 40,
                    child: ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(
                                const Color(0xFF242424))),
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (ctx) => ViewOrderDetails(
                                   order: order,
                                  
                                  )));
                        },
                        child: const Text('Details')),
                  ),
                  Text(
                    order.status,
                    style: const TextStyle(color: Colors.blue),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
