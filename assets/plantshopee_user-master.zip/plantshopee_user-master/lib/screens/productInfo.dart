import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/cartController.dart';
import 'package:plantshopee/customWidgets/popUp/snackbar.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/cart_model.dart';
import 'package:plantshopee/model/plant_model.dart';
import 'package:plantshopee/screens/cartPage.dart';
import 'package:plantshopee/screens/wishlistPage.dart';
import 'package:plantshopee/utils/toast.dart';

class ProductInfo extends StatelessWidget {
  PlantModel model;
  ProductInfo({
    Key? key,
    required this.model,
  }) : super(key: key);
  final _cartController = Get.put(CartController());

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Colors.grey.shade300,
        appBar: AppBar(
          backgroundColor: Colors.grey.shade300,
          foregroundColor: themeColor,
          elevation: 0,
          actions: [
            IconButton(
                onPressed: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (ctx) => FavouritesScreen()));
                },
                icon: const Icon(Icons.favorite)),
            IconButton(
                onPressed: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (ctx) => CartPage()));
                },
                icon: const Icon(Icons.shopping_bag)),
          ],
        ),
        body: Stack(
          children: [
            Align(
                alignment: Alignment.topCenter,
                child: Container(
                  height: size.height * 0.4,
                  width: size.height * 0.4,
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(40)),
                      image:
                          DecorationImage(image: NetworkImage(model.image!))),
                )),
            Positioned(
              bottom: 58,
              left: 10,
              right: 10,
              child: Container(
                height: size.height * 0.41,
                width: size.width,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20))),
                child: SingleChildScrollView(
                  child: Padding(
                    padding:
                        const EdgeInsets.only(left: 10, right: 10, top: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              width: size.width * 0.7,
                              child: Text(
                                model.title,
                                style: header,
                              ),
                            ),
                            Text(
                              '₹ ${model.price}',
                              style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: themeGreen),
                            ),
                          ],
                        ),
                        kHeight15,
                        const Text(
                          'Discription',
                          style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                              fontWeight: FontWeight.bold),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            model.description,
                            style: TextStyle(
                                fontSize: 13, color: Colors.grey.shade700),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              child: SizedBox(
                height: 50,
                width: size.width,
                child: MaterialButton(
                  onPressed: () {
                    showModalBottomSheet(
                        backgroundColor: Colors.transparent,
                        context: context,
                        builder: (ctx) => bottomSheet(size));
                  },
                  color: themeColor,
                  child: const Text(
                    'CHECKOUT',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            )
          ],
        ));
  }

  card({required IconData icon}) => Card(
          child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: IconButton(
          onPressed: () {},
          icon: Icon(icon),
        ),
      ));

  bottomSheet(Size size) => Builder(builder: (context) {
        _cartController.quantity.value = 1;
        return Container(
          width: size.width,
          height: size.height * 0.35,
          decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(35), topRight: Radius.circular(35))),
          child: Padding(
            padding:
                const EdgeInsets.only(top: 30, left: 20, right: 20, bottom: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: size.width * 0.68,
                      height: 50,
                      child: Text(
                        model.title,
                        style: header,
                      ),
                    ),
                    SizedBox(
                      width: size.width * 0.2,
                      child: Text(
                        '₹ ${model.price}',
                        style: const TextStyle(
                            color: themeGreen,
                            fontWeight: FontWeight.w700,
                            fontSize: 18),
                      ),
                    )
                  ],
                ),
                kHeight15,
                (model.quantity <= 0)
                    ? const Text(
                        'Stock not available',
                        style: TextStyle(color: Colors.red),
                      )
                    : const Text(
                        'Stock available',
                        style: TextStyle(color: green),
                      ),
                SizedBox(height: size.height * 0.03),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Quantity',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey.shade800),
                    ),
                    Row(
                      children: [
                        IconButton(
                            onPressed: () {
                              _cartController.decrement();
                            },
                            icon: const Icon(Icons.remove)),
                        Container(
                          width: 50,
                          height: 30,
                          padding: const EdgeInsets.all(3.0),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.blueAccent)),
                          child: Center(child: GetX<CartController>(
                            builder: (controller) {
                              return Text('${controller.quantity}');
                            },
                          )),
                        ),
                        IconButton(
                            onPressed: () {
                              _cartController.increment();
                            },
                            icon: const Icon(Icons.add)),
                      ],
                    ),
                  ],
                ),
                const Spacer(),
                Column(
                  children: [
                    SizedBox(
                      height: 60,
                      width: size.width,
                      child: MaterialButton(
                        color: themeColor,
                        onPressed: () async {
                          if (model.quantity > 0) {
                            final item = CartModel(
                                productId: model.id,
                                quantity: _cartController.quantity.value,
                                price: model.price);
                            final res = await addToCart(item);
                            Navigator.pop(context);
                            toast(context, res,position: false);
                          } else {
                            Fluttertoast.showToast(
                                msg: "Stock not available",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.CENTER,
                                timeInSecForIosWeb: 1,
                                backgroundColor: Colors.red,
                                textColor: Colors.white,
                                fontSize: 16.0);
                          }
                        },
                        child: const Text(
                          "ADD TO CART",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: Colors.white),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    // SizedBox(
                    //   height: 40,
                    //   width: size.width,
                    //   child: MaterialButton(
                    //     color: themeColor,
                    //     onPressed: () {
                    //       addToFav(model.id);
                    //     },
                    //     child: const Text(
                    //       "BUY NOW",
                    //       style: TextStyle(
                    //           fontWeight: FontWeight.bold,
                    //           fontSize: 18,
                    //           color: Colors.white),
                    //     ),
                    //   ),
                    // )
                  ],
                )
              ],
            ),
          ),
        );
      });
}
