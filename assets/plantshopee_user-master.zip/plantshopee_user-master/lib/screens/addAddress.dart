import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/address_controller.dart';
import 'package:plantshopee/customWidgets/popUp/snackbar.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/address_model.dart';

class AddAddress extends StatefulWidget {
  AddressModel? address;
  AddAddress({Key? key, this.address}) : super(key: key);

  @override
  State<AddAddress> createState() => _AddAddressState();
}

class _AddAddressState extends State<AddAddress> {
  final AddressController _controller = Get.find();
  final _nameController = TextEditingController();

  final _mobController = TextEditingController();

  final _altNumrController = TextEditingController();

  final _pinController = TextEditingController();

  final _stateController = TextEditingController();

  final _cityController = TextEditingController();

  final _addressControler = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (widget.address != null) {
      _nameController.text = widget.address!.name;
      _mobController.text = widget.address!.mobNumber;
      _altNumrController.text = widget.address!.alterNumber;
      _pinController.text = widget.address!.pincode;
      _stateController.text = widget.address!.state;
      _cityController.text = widget.address!.city;
      _addressControler.text = widget.address!.address;
    }
  }

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
        title: const Text('Add delivery address'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 15, left: 15, right: 15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(
                          validator: (value) => validateString(value!),
                          controller: _nameController,
                          decoration: InputDecoration(
                              contentPadding: const EdgeInsets.symmetric(
                                  vertical: 14.0, horizontal: 18.0),
                              hintText: 'Full Name',
                              filled: true,
                              fillColor: Colors.grey.shade300,
                              border: const OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10)))),
                        ),
                        kHeight18,
                        TextFormField(
                          validator: (value) => validateMobile(value!),
                          controller: _mobController,
                          decoration: InputDecoration(
                              contentPadding: const EdgeInsets.symmetric(
                                  vertical: 14.0, horizontal: 18.0),
                              hintText: 'Mobile Number',
                              filled: true,
                              fillColor: Colors.grey.shade300,
                              border: const OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10)))),
                        ),
                        kHeight18,
                        TextFormField(
                          validator: (value) => validateMobile(value!),
                          controller: _altNumrController,
                          decoration: InputDecoration(
                              contentPadding: const EdgeInsets.symmetric(
                                  vertical: 14.0, horizontal: 18.0),
                              hintText: 'Alternate Mobile Number',
                              filled: true,
                              fillColor: Colors.grey.shade300,
                              border: const OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10)))),
                        ),
                        kHeight18,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              width: size.width * 0.44,
                              child: TextFormField(
                                validator: (value) => validatePin(value!),
                                controller: _pinController,
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.symmetric(
                                        vertical: 14.0, horizontal: 18.0),
                                    hintText: 'Pincode',
                                    filled: true,
                                    fillColor: Colors.grey.shade300,
                                    border: const OutlineInputBorder(
                                        borderSide: BorderSide.none,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10)))),
                              ),
                            ),
                            SizedBox(
                              width: size.width * 0.44,
                              child: TextFormField(
                                validator: (value) => validateString(value!),
                                controller: _stateController,
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.symmetric(
                                        vertical: 14.0, horizontal: 18.0),
                                    hintText: 'State',
                                    filled: true,
                                    fillColor: Colors.grey.shade300,
                                    border: const OutlineInputBorder(
                                        borderSide: BorderSide.none,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10)))),
                              ),
                            ),
                          ],
                        ),
                        kHeight18,
                        SizedBox(
                          width: size.width * 0.44,
                          child: TextFormField(
                            validator: (value) => validateString(value!),
                            controller: _cityController,
                            decoration: InputDecoration(
                                contentPadding: const EdgeInsets.symmetric(
                                    vertical: 14.0, horizontal: 18.0),
                                hintText: 'City',
                                filled: true,
                                fillColor: Colors.grey.shade300,
                                border: const OutlineInputBorder(
                                    borderSide: BorderSide.none,
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(10)))),
                          ),
                        ),
                        kHeight18,
                        TextFormField(
                            validator: (value) => validateAddress(value!),
                            controller: _addressControler,
                            maxLines: 8,
                            decoration: InputDecoration(
                              hintText: "Full Address",
                              filled: true,
                              fillColor: Colors.grey.shade300,
                              contentPadding: const EdgeInsets.symmetric(
                                  vertical: 14.0, horizontal: 18.0),
                              border: const OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10))),
                            )),
                        kHeight15,
                      ],
                    ),
                  ),
                ],
              ),
              kHeight18,
              SizedBox(
                width: size.width,
                height: 45,
                child: ElevatedButton(
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      if (widget.address == null) {
                        add(context);
                      } else {
                        update(context);
                      }
                    }
                  },
                  child: const Text(
                    "Save Address",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(themeColor)),
                ),
              ),
              kHeight15
            ],
          ),
        ),
      ),
    );
  }

  void add(BuildContext context) async {
    final address = AddressModel(
        name: _nameController.text,
        mobNumber: _mobController.text,
        alterNumber: _altNumrController.text,
        pincode: _pinController.text,
        state: _stateController.text,
        city: _cityController.text,
        address: _addressControler.text);
    final isAddress = await addAddress(address);
    if (isAddress) {
      _controller.getAddress();
      Navigator.pop(context);
    } else {
      showSnackbar(context, 'Some error occured');
    }
  }

  update(BuildContext context) async {
    widget.address!.name = _nameController.text;
    widget.address!.mobNumber = _mobController.text;
    widget.address!.alterNumber = _altNumrController.text;
    widget.address!.pincode = _pinController.text;
    widget.address!.state = _stateController.text;
    widget.address!.city = _cityController.text;
    widget.address!.address = _addressControler.text;
    final isAddress = await updateAddress(widget.address!);
    if (isAddress) {
      _controller.getAddress();
      Navigator.pop(context);
    } else {
      showSnackbar(context, 'Some error occured');
    }
  }
}

validateMobile(String value) {
  if (value.length != 10) {
    return 'Mobile Number must be of 10 digit';
  } else {
    return null;
  }
}

validateString(String value) {
  if (value.length < 4) {
    return 'Please enter at least 4 character';
  } else {
    return null;
  }
}

validatePin(String value) {
  if (value.length < 6) {
    return 'Please enter currect pin code';
  } else {
    return null;
  }
}

validateAddress(String value) {
  if (value.length < 8) {
    return 'Please enter at least 4 character';
  } else {
    return null;
  }
}
