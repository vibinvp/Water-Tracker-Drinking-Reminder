import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/address_controller.dart';
import 'package:plantshopee/controller/notifications.dart';
import 'package:plantshopee/controller/radio_btn_controller.dart';
import 'package:plantshopee/customWidgets/cart_tile.dart';
import 'package:plantshopee/customWidgets/popUp/snackbar.dart';
import 'package:plantshopee/customWidgets/shippingAddress.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/address_model.dart';
import 'package:plantshopee/model/cart_model.dart';
import 'package:plantshopee/model/order_model.dart';
import 'package:plantshopee/payment/razorpay.dart';
import 'package:plantshopee/screens/addAddress.dart';
import 'package:plantshopee/screens/successPage.dart';
import 'package:plantshopee/utils/cart_totalsum.dart';
import 'package:plantshopee/utils/toast.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

class CheckoutPage extends StatelessWidget {
  CheckoutPage({
    Key? key,
  }) : super(key: key);

  double? totalPrice;
  List<CartModel>? cartModel;
  final AddressController _controller = Get.find();
  final radioController = Get.put(RadioController());
  final _razorpay = Razorpay();
  final NotificationController _notification = Get.find();
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    _controller.address = null;
    _controller.getAddress();
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'Check out',
          style: subHeading,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: ListView(
          children: [
            StreamBuilder<List<CartModel>>(
              stream: getAllCartItems(),
              builder: (context, item) {
                if (item.data == null) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                } else {
                  if (item.data!.isEmpty) {
                    return const Center(
                      child: Text("No Cart Items Found"),
                    );
                  } else {
                    return ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: ((context, index) {
                          final cart = getCart(item.data![index].productId);
                          final quantity = item.data![index].quantity;
                          return createCartListItem(cart, quantity);
                        }),
                        itemCount: item.data!.length);
                  }
                }
              },
            ),
            kHeight18,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Shipping Address',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
                Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        if (_controller.address == null) {
                          showSnackbar(context, 'Please select an address');
                        } else {
                          Navigator.of(context)
                              .pushReplacement(MaterialPageRoute(
                                  builder: (ctx) => AddAddress(
                                        address: _controller.address,
                                      )));
                        }
                      },
                      icon: const Icon(
                        Icons.edit_note,
                        color: Colors.blue,
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        Navigator.of(context).pushReplacement(
                            MaterialPageRoute(builder: (ctx) => AddAddress()));
                      },
                      icon: const Icon(
                        Icons.add,
                        color: Colors.blue,
                      ),
                    ),
                  ],
                )
              ],
            ),
            kHeight18,
            GetBuilder<AddressController>(
              builder: (item) {
                if (item.allAddress.isNotEmpty) {
                  return ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: item.allAddress.length,
                      itemBuilder: (ctx, index) => RadioListTile(
                            contentPadding: const EdgeInsets.all(0),
                            title: ShippingAddress(
                              address: item.allAddress[index],
                            ),
                            value: item.allAddress[index],
                            groupValue: item.address,
                            onChanged: (value) =>
                                item.addressSelector(value as AddressModel),
                          ));
                } else {
                  return const Center(
                    child: Text('Please add an Address'),
                  );
                }
              },
            ),
            // const ShippingAddress(),
            kHeight18,
            const Text(
              'Payment',
              style: subHeading,
            ),
            kHeight18,
            GetBuilder<RadioController>(
              builder: (radio) {
                return Column(
                  children: <Widget>[
                    RadioListTile(
                        title: const Text('RazorPay'),
                        value: 'RazorPay',
                        groupValue: radio.payment,
                        onChanged: (value) => radio.onClickRadioButton(value)),
                    // RadioListTile(
                    //     title: const Text('PayTm'),
                    //     value: 'PayTm',
                    //     groupValue: radio.payment,
                    //     onChanged: (value) => radio.onClickRadioButton(value)),
                    RadioListTile(
                        title: const Text('COD'),
                        value: 'COD',
                        groupValue: radio.payment,
                        onChanged: (value) => radio.onClickRadioButton(value)),
                  ],
                );
              },
            ),
            SizedBox(
              height: size.height * 0.09,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Total",
                  style: subHeading,
                ),
                StreamBuilder<List<CartModel>>(
                    stream: getAllCartItems(),
                    builder: (context, item) {
                      double sum = 0;
                      if (item.data == null) {
                        return const SizedBox();
                      } else {
                        sum = totalSum(item.data!);
                        totalPrice = sum;
                        cartModel = item.data!;
                        return Text(
                          "₹ $sum",
                          style: subHeading,
                        );
                      }
                    })
              ],
            ),
            kHeight18,
            Align(
              alignment: Alignment.bottomCenter,
              child: SizedBox(
                width: size.width,
                height: 45,
                child: ElevatedButton(
                  onPressed: () async {
                    if (_controller.address == null) {
                      toast(context, 'Please select an Address');
                    } else {
                      if (radioController.payment == 'RazorPay') {
                        RazorPay(
                                order: chekOut,
                                context: context,
                                price: totalPrice!)
                            .razorpay();
                      } else {
                        codAlert(context);
                      }
                    }
                  },
                  child: const Text(
                    "Submit Order",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(themeColor)),
                ),
              ),
            ),
            kHeight15
          ],
        ),
      ),
    );
  }

  void chekOut() async {
    for (var item in cartModel!) {
      String userName = await getUserName();
      final order = OrderModel(
          address: _controller.address!,
          status: 'processing',
          totalPrice: item.price * item.quantity,
          cartModel: item,
          userName: userName,
          createdDate: DateTime.now(),
          payment: radioController.payment);
      await addOrders(order);
      await decreaseQuantity(item.productId, item.quantity);
    }
  }

  cod(BuildContext context) async {
    String userName = await getUserName();
    for (var item in cartModel!) {
      final order = OrderModel(
          address: _controller.address!,
          status: 'processing',
          totalPrice: item.price * item.quantity,
          cartModel: item,
          userName: userName,
          createdDate: DateTime.now(),
          payment: radioController.payment);
      await addOrders(order).then((value) async {
        await decreaseQuantity(item.productId, item.quantity);
      });
    }
    await clearCart(FirebaseAuth.instance.currentUser!.uid);
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (ctx) => const SuccessPage()));
    _notification.sendPushMessage(_notification.mtoken!,
        FirebaseAuth.instance.currentUser!.uid, 'New Order Placed');
  }

  Future<String?> codAlert(BuildContext context) {
    return showDialog<String>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('Are you sure want to order this plant ?'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              cod(context);
              Navigator.pop(ctx);
              Navigator.pop(context);
            },
            child: const Text(
              'OK',
            ),
          ),
        ],
      ),
    );
  }
}
