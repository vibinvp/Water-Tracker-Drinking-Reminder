import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/authentication/auth_helper.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/userDetails_controller.dart';
import 'package:plantshopee/main.dart';
import 'package:plantshopee/screens/cartPage.dart';
import 'package:plantshopee/screens/home.dart';
import 'package:plantshopee/screens/orderDetails/myOrder.dart';
import 'package:plantshopee/screens/profilePage.dart';
import 'package:plantshopee/screens/wishlistPage.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
              padding: const EdgeInsets.only(top: 20),
              decoration: const BoxDecoration(color: themeGreen),
              child: GetBuilder<UserDetailsController>(
                builder: (controller) {
                  final user = controller.userModel;
                  if (user == null) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  } else {
                    return Column(
                      children: [
                        CircleAvatar(
                            radius: 40,
                            backgroundImage: (user.image != null)
                                ? NetworkImage(user.image!)
                                : const AssetImage('assets/images/profile.png')
                                    as ImageProvider),
                        const SizedBox(
                          height: 10,
                        ),
                        Text(
                          user.username,
                          style: const TextStyle(color: Colors.white),
                        ),
                        Text(
                          user.email,
                          style: const TextStyle(
                              fontWeight: FontWeight.w300, color: Colors.white),
                        )
                      ],
                    );
                  }
                },
              )),
          // ListTile(
          //   leading: const Icon(Icons.category),
          //   title: const Text('All Categories'),
          //   onTap: () {
          //     // Update the state of the app.
          //     // ...
          //   },
          // ),
          ListTile(
            leading: const Icon(Icons.home),
            title: const Text('Home'),
            onTap: () {
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (ctx) => const Home()),
                  (route) => false);
            },
          ),
          ListTile(
            leading: const Icon(Icons.shopping_bag),
            title: const Text('My Cart'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (ctx) => CartPage()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.favorite),
            title: const Text('My Favourites'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (ctx) => FavouritesScreen()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.account_circle),
            title: const Text('My Account'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (ctx) => ProfilePage()));
            },
          ),
          ListTile(
            leading: const Icon(Icons.local_shipping),
            title: const Text('My Orders'),
            onTap: () {
              Navigator.pop(context);
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (ctx) => MyOrder()));
            },
          ),
          // ListTile(
          //   leading: const Icon(Icons.notifications),
          //   title: const Text('Notifications'),
          //   onTap: () {
          //     Navigator.pop(context);
          //     // Update the state of the app.
          //     // ...
          //   },
          // ),
          const Divider(
            thickness: 1,
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('About'),
            onTap: () {
              Navigator.pop(context);
              _showAbout(context);
              // Update the state of the app.
              // ...
            },
          ),
          ListTile(
            leading: const Icon(Icons.privacy_tip),
            title: const Text('Privacy Policy'),
            onTap: () {
              Navigator.pop(context);
              // Update the state of the app.
              // ...
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Logout'),
            onTap: () {
              Navigator.pop(context);
              AuthMethods().logoutUser();
            },
          ),
        ],
      ),
    );
  }
}

Future<dynamic> _showAbout(BuildContext context) {
  return showDialog(
    context: context,
    builder: (context) {
      return AboutDialog(
        applicationName: "Plant Shopee",
        applicationVersion: "Version 1.0.0",
        applicationIcon: Image.asset(
          'assets/images/logo.png',
          width: 60.0,
          height: 60.0,
        ),
      );
    },
  );
}
