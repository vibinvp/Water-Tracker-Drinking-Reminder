import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/controller/notifications.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/screens/failedpage.dart';
import 'package:plantshopee/screens/successPage.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:plantshopee/controller/userDetails_controller.dart';

class RazorPay {
  final NotificationController _notification = Get.find();
  Function order;
  BuildContext context;
  double price;
  RazorPay({
    required this.order,
    required this.context,
    required this.price,
  });
  final _razorpay = Razorpay();

  void razorpay() async {
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    // _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    final UserDetailsController userController = Get.find();
    var options = {
      'key': 
      'amount': price * 100,
      'name': userController.userModel!.username,
      // 'description': order.cartModel.map((e) => e.productId),
      'timeout': 60,
      'prefill': {
        'contact': userController.userModel!.mobileNumber,
        'email': userController.userModel!.email
      }
    };
    try {
      _razorpay.open(options);
    } catch (err) {
      print(err);
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    order();
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (ctx) => const SuccessPage()),
        (route) => false);
    clearCart(FirebaseAuth.instance.currentUser!.uid);
    _notification.sendPushMessage(_notification.mtoken!,
        FirebaseAuth.instance.currentUser!.uid, 'New Order Placed');
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (ctx) => const FailedPage()),
        (route) => false);
  }

  // void _handleExternalWallet(ExternalWalletResponse response) {
  //   print('....................');
  // }
}
