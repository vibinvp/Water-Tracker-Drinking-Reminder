import 'package:flutter/material.dart';

const kHeight18 = SizedBox(
  height: 18,
);
const kHeight15 = SizedBox(
  height: 15,
);

Color bgColor = Colors.grey.shade300;
const green = Color.fromARGB(255, 35, 238, 69);
const themeColor = Color(0xFF184A2C);
const header = TextStyle(fontSize: 20, fontWeight: FontWeight.bold);
const subHeading = TextStyle(fontSize: 18, fontWeight: FontWeight.w600);
const themeGreen = Color.fromARGB(255, 49, 163, 68);
const delete = Color.fromARGB(255, 236, 119, 110);
const bgCard = Color.fromARGB(255, 251, 251, 251);

//////////////////////////////////

// const bgLight = Color(0xFFEBFDF2);
// const bgLight = Color.fromARGB(255, 6, 84, 94);
