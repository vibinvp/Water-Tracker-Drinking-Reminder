import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/address_controller.dart';
import 'package:plantshopee/model/address_model.dart';

class ShippingAddress extends StatelessWidget {
  AddressModel address;
  bool? status;
  ShippingAddress({
    Key? key,
    required this.address,
    this.status
  }) : super(key: key);
  final AddressController _addressController = Get.find();
  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color.fromARGB(255, 251, 251, 251),
      child: SizedBox(
        width: double.infinity,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    address.name,
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                 (status == null) ? InkWell(
                      onTap: () {
                        _addressController.deleteAddress(address.id!);
                      },
                      child: const Icon(
                        Icons.delete,
                        color: delete,
                      )) : const SizedBox(),
                ],
              ),
              const Divider(
                thickness: 1,
              ),
              Text(address.mobNumber),
              Text(address.alterNumber),
              Text(address.state),
              Text(address.city),
              Text(address.pincode),
              Text(address.address),
            ],
          ),
        ),
      ),
    );
  }
}
