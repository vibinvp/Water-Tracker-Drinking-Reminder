import 'package:flutter/material.dart';

import 'package:plantshopee/constanse/constanse.dart';
import 'package:plantshopee/controller/favourite_controller.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/favourite_model.dart';
import 'package:plantshopee/model/plant_model.dart';

class Plant extends StatelessWidget {
  PlantModel model;
  List<FavouritesModel> fav;
  Plant({Key? key, required this.model, required this.fav}) : super(key: key);

  bool isFav = false;

  @override
  Widget build(BuildContext context) {
    for (var item in fav) {
      if (item.productId == model.id) {
        isFav = true;
      }
    }
    Size size = MediaQuery.of(context).size;
    return Card(
      color: Colors.grey.shade100,
      child: Padding(
        padding: const EdgeInsets.only(top: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          fit: BoxFit.contain,
                          image: NetworkImage(model.image!)),
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                    ),
                    width: size.width * 0.4,
                    height: size.width * 0.4,
                  ),
                ),
                Positioned(
                    right: 0,
                    top: 0,
                    child: IconButton(
                        onPressed: () {
                          if (isFav) {
                            FavouriteController().deleteFav(model.id);
                          } else {
                            addToFav(context, model.id);
                          }
                        },
                        icon: isFav
                            ? const Icon(
                                Icons.favorite,
                                color: Colors.red,
                              )
                            : const Icon(Icons.favorite_outline)))
              ],
            ),
            const SizedBox(
              height: 5,
            ),
            Padding(
              padding: EdgeInsets.only(left: size.width * 0.03),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    model.title,
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.grey.shade600,
                        fontSize: 16,
                        overflow: TextOverflow.ellipsis),
                  ),
                  const SizedBox(
                    height: 3,
                  ),
                  Text(
                    '₹ ${model.price}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                        color: themeGreen),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
