import 'package:flutter/material.dart';

class AmountContainer extends StatelessWidget {
  const AmountContainer({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color.fromARGB(255, 251, 251, 251),
      child: Column(
        children: [
          AmountRowBetween(
            name: 'Order',
            amount: '799.00',
          ),
         const Divider(),
          AmountRowBetween(
            name: 'Delivery',
            amount: '5.00',
          ),
         const Divider(),
          AmountRowBetween(
            name: 'Total',
            amount: '100.00',
          )
        ],
      ),
    );
  }
}
class AmountRowBetween extends StatelessWidget {
  String name;
  String amount;
  AmountRowBetween({Key? key, required this.name, required this.amount})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text('$name :'), Text('₹ $amount')],
      ),
    );
  }
}