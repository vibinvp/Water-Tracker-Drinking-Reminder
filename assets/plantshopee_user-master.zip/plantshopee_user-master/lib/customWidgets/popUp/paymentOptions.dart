import 'package:flutter/material.dart';
import 'package:plantshopee/constanse/constanse.dart';

paymentOptions(BuildContext context) {
  return SimpleDialog(
    title: const Text('Select Payment Options',style: subHeading,),
    children: <Widget>[
      SimpleDialogOption(
        onPressed: () {
          Navigator.pop(context);
        },
        child: const Text('RazorPay'),
      ),
      SimpleDialogOption(
        onPressed: () {
          Navigator.pop(context);
        },
        child: const Text('G-pay'),
      ),
      SimpleDialogOption(
        onPressed: () {
          Navigator.pop(context);
        },
        child: const Text('COD'),
      ),
    ],
  );
}