import 'package:flutter/material.dart';
import 'package:plantshopee/firebase/firebase_fun.dart';
import 'package:plantshopee/model/plant_model.dart';
import 'package:plantshopee/utils/CustomTextStyle.dart';
import 'package:plantshopee/utils/CustomUtils.dart';

createCartListItem(Stream<PlantModel> cartStream, int quantity) {
    return StreamBuilder<PlantModel>(
        stream: cartStream,
        builder: (context, snapshot) {
          if (snapshot.data != null) {
            final cart = snapshot.data;
            return Stack(
              children: <Widget>[
                Card(
                  color: Colors.grey.shade100,
                  child: Row(
                    children: <Widget>[
                      Container(
                        margin: const EdgeInsets.only(
                            right: 8, left: 8, top: 8, bottom: 8),
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                            borderRadius:
                                const BorderRadius.all(Radius.circular(14)),
                            color: Colors.grey.shade200,
                            image: DecorationImage(
                                image: NetworkImage(cart!.image!))),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                padding:
                                    const EdgeInsets.only(right: 8, top: 4),
                                child: Text(
                                  cart.title,
                                  maxLines: 2,
                                  softWrap: true,
                                  style: CustomTextStyle.textFormFieldSemiBold
                                      .copyWith(fontSize: 14),
                                ),
                              ),
                              Utils.getSizedBox(height: 6),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Text(
                                    "₹${cart.price}",
                                    style: CustomTextStyle.textFormFieldBlack
                                        .copyWith(color: Colors.green),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: <Widget>[
                                        InkWell(
                                          onTap: () {
                                            decrementQuantity(cart.id);
                                          },
                                          child: Icon(
                                            Icons.remove,
                                            size: 24,
                                            color: Colors.grey.shade700,
                                          ),
                                        ),
                                        Container(
                                            color: Colors.grey.shade200,
                                            padding: const EdgeInsets.only(
                                                bottom: 2, right: 12, left: 12),
                                            child: Text('$quantity')),
                                        InkWell(
                                          onTap: () {
                                            incrementQuantity(cart.id);
                                          },
                                          child: Icon(
                                            Icons.add,
                                            size: 24,
                                            color: Colors.grey.shade700,
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ],
                          ),
                        ),
                        flex: 100,
                      )
                    ],
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Container(
                    width: 24,
                    height: 24,
                    alignment: Alignment.center,
                    margin: const EdgeInsets.only(right: 10, top: 8),
                    child: InkWell(
                      onTap: () {
                        deleteCartItems(cart.id);
                      },
                      child: const Icon(
                        Icons.close,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                        color: Colors.green),
                  ),
                )
              ],
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        });
  }