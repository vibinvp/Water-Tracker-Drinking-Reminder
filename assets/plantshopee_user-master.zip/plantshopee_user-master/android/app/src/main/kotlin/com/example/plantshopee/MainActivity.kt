package com.example.plantshopee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
